# Matt Woods Details Form Wordpress Plugin

Version 1.0

This is Wordpress plugin which allows the user to update certain details and update some optional fields

# Compiling Sass

* cd directory
* $ npm install
* $ composer install
* $ gulp
